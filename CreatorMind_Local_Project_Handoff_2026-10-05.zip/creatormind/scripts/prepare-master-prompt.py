from pathlib import Path

root = Path(__file__).resolve().parents[1]
original = Path(r"C:\Users\pmathala\Downloads\CreatorMind_Master_Prompts.txt")
new_ui = (root / "prompts" / "FRONTEND_UI_PROMPT.md").read_text(encoding="utf-8").strip()
content = original.read_text(encoding="utf-8")
start = content.index("------------------------------------------------------------------------\n1. FRONTEND UI GENERATION PROMPT")
end = content.index("------------------------------------------------------------------------\n2. CORE AI VIDEO ANALYSIS PROMPT", start)
replacement = (
    "------------------------------------------------------------------------\n"
    "1. FRONTEND UI GENERATION PROMPT (Local App v2)\n"
    "------------------------------------------------------------------------\n"
    f"{new_ui}\n\n\n"
)
result = content[:start] + replacement + content[end:]
output = root / "prompts" / "CreatorMind_Master_Prompts_v2.txt"
output.write_text(result, encoding="utf-8")
print(output)
