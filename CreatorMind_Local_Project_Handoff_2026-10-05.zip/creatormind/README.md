# CreatorMind local UI

A responsive React, TypeScript, Tailwind CSS, and Lucide workspace for the CreatorMind B-roll orchestrator. All project, asset, EDL, localization, and telemetry content comes from `src/data/*.json`. No cloud credentials or database are needed.

## Run

```bash
cd creatormind
npm install
npm run dev
```

Open the local URL printed by Vite. Build with `npm run build`.

## Local workflow

- Choose **Take a quick tour** on the home page for a five-step explanation of the player, edit ideas, timeline, regional versions, and demo status. Each block also has a `?` button to reopen its explanation.
- The player opens with a bundled 720p Sintel trailer with stereo AAC audio. Select **Load video** to replace it with your own local video. Playback starts unmuted; volume and mute controls appear below the player. The demo trailer is separate from the seeded JAPAC FinTech EDL data.
- Select **Find edit ideas** to reveal the full set of local suggestions.
- Select a colored timeline idea to inspect matching clips and graphics, then add or remove it from your edit plan.
- Switch JAPAC markets to see regional examples and cultural swaps. Open **Localize**, edit the selected country's script, and select **Apply**. Each country's draft and applied script persist in browser storage.
- Download an applied regional script as a text file. Select **Download edit plan** on Home to export queued edit ideas and applied regional scripts as JSON. Downloads are generated locally.

The live labels and telemetry are simulated. Media files selected in the browser are held only in memory, so reloading the page returns to the bundled sample. Audio playback requires an audio track in a browser-supported video file. See [media attribution](public/media/ATTRIBUTION.md) for the sample license.

Applying a regional script changes the text in the local plan only. The app does not translate or dub the video audio, generate a voice track, or render a localized MP4. The sample trailer is unrelated to the seeded FinTech edit timeline.

For current status, architecture context, and prioritized next steps, see [the project handoff](docs/CreatorMind_Project_Handoff.pdf).
