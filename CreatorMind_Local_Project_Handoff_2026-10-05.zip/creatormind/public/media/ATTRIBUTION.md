# Bundled playback sample

- **Title:** Sintel Trailer, 720p
- **Creator:** Durian Open Movie Team / Blender Foundation
- **Source:** https://download.blender.org/durian/trailer/sintel_trailer-720p.mp4
- **License:** Creative Commons Attribution 3.0 Unported — https://creativecommons.org/licenses/by/3.0/
- **Attribution text:** “Sintel” © Blender Foundation / www.sintel.org, licensed CC BY 3.0.
- **File:** `sintel-trailer-720p.mp4` (unchanged from the source)
- **Media:** 1280×720, about 52 seconds, H.264 video and AAC stereo audio, about 7.6 MB.

The trailer demonstrates real local media playback and audio. It is not the JAPAC FinTech master footage represented by the seeded EDL fixture.
