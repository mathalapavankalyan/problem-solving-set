export type View = 'dashboard' | 'vault' | 'localizer' | 'health';
export type Severity = 'info' | 'warning' | 'critical';
export type Suggestion = {
  id: string; start: number; end: number; title: string; shortTitle: string;
  kind: string; severity: Severity; track: number; issue: string; action: string;
  queries: string[]; assetIds: string[];
};
export type Asset = {
  id: string; title: string; file: string; type: string; duration: string;
  region: string; match: number; tags: string[]; palette: string;
};
export type Market = {
  code: string; name: string; flag: string; hub: string; tone: string;
  audience: string; tip: string; postingWindow: string; hashtags: string[];
  script: string; swaps: { from: string; to: string }[];
};
export type Project = {
  id: string; name: string; creator: string; fileName: string; sizeLabel: string;
  durationSeconds: number; resolution: string; fps: number; storagePath: string;
  script: string;
  analysis: { model: string; pacing: string; confidence: number; speechPercent: number; visualPercent: number; warningAt: number; warningText: string; staticSeconds: number };
  chapters: { id: string; label: string; start: number; end: number }[];
};
export type Telemetry = {
  region: string; modelRegion: string; latencySeconds: number; uploadRateMbps: number;
  semanticAssetCount: number; uptimePercent: number;
  nodes: { id: string; name: string; detail: string; status: string }[];
};
