import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Check, Clapperboard, Compass, Download, FileJson2, Film, Sparkles, X } from 'lucide-react';
import { assets, markets, project, suggestions } from './data';
import { Sidebar } from './components/Sidebar';
import { Topbar } from './components/Topbar';
import { VideoWorkspace } from './components/VideoWorkspace';
import { CopilotCard } from './components/CopilotCard';
import { Timeline } from './components/Timeline';
import { LocalizerCard } from './components/LocalizerCard';
import { TelemetryCard } from './components/TelemetryCard';
import { SuggestionDialog } from './components/SuggestionDialog';
import { MediaVault } from './components/MediaVault';
import { LocalizationPage } from './components/LocalizationPage';
import { HealthPage } from './components/HealthPage';
import { AssetArtwork } from './components/Artwork';
import { TourGuide } from './components/TourGuide';
import { UtilityDialog } from './components/UtilityDialog';
import { Eyebrow, cx } from './components/ui';
import { usePersistedState } from './hooks/usePersistedState';
import { downloadJson, downloadText, timecode } from './lib/format';
import type { Asset, Suggestion, View } from './types';

export default function App() {
  const [view,setView] = useState<View>('dashboard');
  const [mobileOpen,setMobileOpen] = useState(false);
  const [marketCode,setMarketCode] = usePersistedState('cm-market','JP');
  const [queuedIds,setQueuedIds] = usePersistedState<string[]>('cm-queued-edits',[]);
  const [assignedAssets,setAssignedAssets] = usePersistedState<Record<string,string>>('cm-assigned-assets',{});
  const [scriptDrafts,setScriptDrafts] = usePersistedState<Record<string,string>>('cm-script-drafts',{});
  const [appliedScripts,setAppliedScripts] = usePersistedState<Record<string,string>>('cm-applied-scripts',{});
  const [selectedId,setSelectedId] = useState(suggestions[0].id);
  const [dialogSuggestion,setDialogSuggestion] = useState<Suggestion|null>(null);
  const [dialogAsset,setDialogAsset] = useState<Asset|null>(null);
  const [videoFile,setVideoFile] = useState<File|null>(null);
  const [videoSource,setVideoSource] = useState<string|null>(null);
  const [analyzing,setAnalyzing] = useState(false);
  const [analyzed,setAnalyzed] = useState(false);
  const [query,setQuery] = useState('');
  const [toast,setToast] = useState('');
  const [utility,setUtility] = useState<'help'|'settings'|'notifications'|null>(null);
  const [reduceMotion,setReduceMotion] = usePersistedState('cm-reduce-motion',false);
  const [tourStep,setTourStep] = useState<number|null>(null);
  const analysisTimer=useRef<number|null>(null);
  const toastTimer=useRef<number|null>(null);
  const selected=suggestions.find(item=>item.id===selectedId)??suggestions[0];
  const market=markets.find(item=>item.code===marketCode)??markets[0];
  const scriptDraft=scriptDrafts[market.code]??market.script;
  const appliedScript=appliedScripts[market.code]??null;

  useEffect(()=>()=>{if(videoSource)URL.revokeObjectURL(videoSource)},[videoSource]);
  useEffect(()=>()=>{if(analysisTimer.current)window.clearTimeout(analysisTimer.current);if(toastTimer.current)window.clearTimeout(toastTimer.current)},[]);
  const notify=(message:string)=>{setToast(message);if(toastTimer.current)window.clearTimeout(toastTimer.current);toastTimer.current=window.setTimeout(()=>setToast(''),3500)};
  const upload=(file:File)=>{if(!file.type.startsWith('video/')){notify('Please select a video file.');return}setVideoFile(file);setVideoSource(URL.createObjectURL(file));setAnalyzed(false);notify(`${file.name} loaded for local preview`)};
  const analyze=()=>{if(analyzing)return;setAnalyzing(true);analysisTimer.current=window.setTimeout(()=>{setAnalyzing(false);setAnalyzed(true);notify('Analysis complete · 3 edit opportunities identified')},1100)};
  const selectSuggestion=(suggestion:Suggestion)=>{setSelectedId(suggestion.id);setDialogSuggestion(suggestion)};
  const queue=()=>{if(!dialogSuggestion)return;const id=dialogSuggestion.id;const adding=!queuedIds.includes(id);setQueuedIds(ids=>adding?[...ids,id]:ids.filter(item=>item!==id));notify(adding?'Edit added to your plan':'Edit removed from your plan')};
  const updateScript=(value:string)=>setScriptDrafts(current=>({...current,[market.code]:value}));
  const resetScript=()=>{updateScript(market.script);notify(`Suggested ${market.name} wording restored`)};
  const applyScript=()=>{const value=scriptDraft.trim();if(!value){notify('Add some script text before applying.');return}setAppliedScripts(current=>({...current,[market.code]:value}));setScriptDrafts(current=>({...current,[market.code]:value}));notify(`${market.name} script added to your edit plan`)};
  const downloadScript=()=>{if(!appliedScript||appliedScript!==scriptDraft)return;downloadText(`creatormind-${market.code.toLowerCase()}-script.txt`,`${market.name} regional script\nProject: ${project.fileName}\n\n${appliedScript}\n`);notify(`${market.name} script downloaded`)};
  const exportEdl=()=>{downloadJson('creatormind-japac-edl.json',{projectId:project.id,source:videoFile?.name??project.fileName,market:market.code,regionalScript:appliedScript,regionalScripts:appliedScripts,generatedAt:new Date().toISOString(),analysisMetadata:{durationSeconds:project.durationSeconds,detectedPacingDensity:project.analysis.pacing},editDecisionTimeline:suggestions.filter(item=>queuedIds.includes(item.id)).map(item=>({timestampStart:timecode(item.start),timestampEnd:timecode(item.end),severity:item.severity,issueDescription:item.issue,suggestedAction:item.action,vectorSearchQueries:item.queries,asset:assets.find(asset=>asset.id===assignedAssets[item.id])?.file??assets.find(asset=>asset.id===item.assetIds[0])?.file}))});notify('Your edit plan was downloaded')};
  const search=()=>{setView('vault');window.setTimeout(()=>document.querySelector<HTMLInputElement>('.vault-search input')?.focus(),40)};

  return <div className={cx('app-shell',reduceMotion&&'reduce-motion')}><Sidebar view={view} onView={setView} mobileOpen={mobileOpen} onMobileOpen={setMobileOpen} onUtility={setUtility}/><div className="app-main"><Topbar view={view} onNavigate={setView} onSearch={search} onNotifications={()=>setUtility('notifications')}/><main className="main-content">{view==='dashboard'&&<>
    <div className="dashboard-hero"><div><Eyebrow icon={<Sparkles size={13}/>} tone="purple">CreatorMind studio <span className="eyebrow-divider">/</span> Your project</Eyebrow><h1>Shape the story<span className="heading-dot">.</span></h1><p>Review your video, pick helpful visuals, and prepare versions for each audience.</p></div><div className="hero-actions"><button className="tour-launch-button" onClick={()=>setTourStep(0)}><Compass size={15}/> Take a quick tour</button><button className="export-button" onClick={exportEdl}><Download size={15}/> Download edit plan <span>{queuedIds.length}</span></button></div></div>
    <div className="dashboard-grid"><VideoWorkspace file={videoFile} source={videoSource} onUpload={upload} onToast={notify} onHelp={()=>setTourStep(0)}/><CopilotCard analyzing={analyzing} analyzed={analyzed} onAnalyze={analyze} onHelp={()=>setTourStep(1)}/><Timeline selectedId={selectedId} onSelect={selectSuggestion} analyzed={analyzed} queued={queuedIds} onHelp={()=>setTourStep(2)}/><div className="selected-strip"><div><span className="selected-strip-icon"><Clapperboard size={16}/></span><div><small>SELECTED IDEA · {timecode(selected.start)}</small><strong>{selected.title}</strong></div></div><p>{selected.action}</p><button onClick={()=>setDialogSuggestion(selected)}>See details <ArrowRight size={14}/></button></div><LocalizerCard marketCode={marketCode} onMarket={setMarketCode} onOpen={()=>setView('localizer')} onHelp={()=>setTourStep(3)}/><TelemetryCard onHelp={()=>setTourStep(4)}/></div>
  </>}{view==='vault'&&<MediaVault query={query} onQuery={setQuery} onAsset={setDialogAsset}/>} {view==='localizer'&&<LocalizationPage marketCode={marketCode} onMarket={setMarketCode} onToast={notify} draft={scriptDraft} applied={appliedScript} onDraft={updateScript} onApply={applyScript} onReset={resetScript} onDownload={downloadScript}/>} {view==='health'&&<HealthPage/>}<footer className="app-footer"><span>CREATORMIND <i>✦</i> LOCAL STUDIO</span><span>JAPAC FinTech launch <b>·</b> Draft saved locally</span></footer></main></div>
    <SuggestionDialog suggestion={dialogSuggestion} queued={Boolean(dialogSuggestion&&queuedIds.includes(dialogSuggestion.id))} selectedAssetId={dialogSuggestion?assignedAssets[dialogSuggestion.id]??null:null} onAsset={asset=>{if(dialogSuggestion)setAssignedAssets(current=>({...current,[dialogSuggestion.id]:asset.id}))}} onQueue={queue} onClose={()=>setDialogSuggestion(null)}/>
    {dialogAsset&&<div className="dialog-backdrop" onMouseDown={event=>{if(event.target===event.currentTarget)setDialogAsset(null)}}><div className="vault-dialog" role="dialog" aria-modal="true" aria-labelledby="asset-title"><button className="close-button" onClick={()=>setDialogAsset(null)} aria-label="Close asset"><X size={18}/></button><AssetArtwork asset={dialogAsset} className="vault-dialog-art"/><div className="vault-dialog-content"><Eyebrow icon={<FileJson2 size={13}/>} tone="cyan">Media library · {dialogAsset.region}</Eyebrow><h2 id="asset-title">{dialogAsset.title}</h2><p>{dialogAsset.file}</p><div className="vault-dialog-tags">{dialogAsset.tags.map(tag=><span key={tag}>{tag}</span>)}</div><div className="vault-dialog-meta"><span>How well it fits <strong>{dialogAsset.match}%</strong></span><span>Length <strong>{dialogAsset.duration}</strong></span><span>Type <strong>{dialogAsset.type}</strong></span></div><button className="gradient-action" onClick={()=>{const match=suggestions.find(item=>item.assetIds.includes(dialogAsset.id));setDialogAsset(null);if(match){setView('dashboard');setSelectedId(match.id);setDialogSuggestion(match)}else notify('Clip is available in your media library')}}><Film size={15}/> View timeline <ArrowRight size={15}/></button></div></div></div>}
    {tourStep!==null&&<TourGuide step={tourStep} onStep={setTourStep} onClose={()=>setTourStep(null)}/>} 
    <UtilityDialog panel={utility} onClose={()=>setUtility(null)} onStartTour={()=>setTourStep(0)} reduceMotion={reduceMotion} onReduceMotion={setReduceMotion}/>
    {toast&&<div className="toast" role="status"><Check size={15}/>{toast}<button onClick={()=>setToast('')} aria-label="Dismiss notification"><X size={13}/></button></div>}
  </div>;
}
