import projectJson from './project.json';
import suggestionsJson from './suggestions.json';
import assetsJson from './assets.json';
import marketsJson from './markets.json';
import telemetryJson from './telemetry.json';
import type { Project, Suggestion, Asset, Market, Telemetry } from '../types';

export const project = projectJson as Project;
export const suggestions = suggestionsJson as Suggestion[];
export const assets = assetsJson as Asset[];
export const markets = marketsJson as Market[];
export const telemetry = telemetryJson as Telemetry;
