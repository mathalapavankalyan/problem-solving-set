import { ArrowUpRight, AudioLines, BrainCircuit, Check, LoaderCircle, Sparkles, TriangleAlert, WandSparkles } from 'lucide-react';
import { project } from '../data';
import { Card, Eyebrow, StatusDot } from './ui';
import { TourHelpButton } from './TourGuide';

export function CopilotCard({ analyzing, analyzed, onAnalyze, onHelp }: { analyzing: boolean; analyzed: boolean; onAnalyze: () => void; onHelp: () => void }) {
  return <Card className="copilot-card" data-tour="ideas"><div className="copilot-glow"/><div className="card-heading"><div><Eyebrow icon={<Sparkles size={13}/>} tone="purple">Editing ideas</Eyebrow><h2>Where visuals can help</h2><p>Find moments that could use a clip, chart, or close-up</p></div><div className="card-heading-actions"><span className="pill pill-green"><StatusDot/> {analyzing ? 'Working' : 'Demo ready'}</span><TourHelpButton onClick={onHelp} label="editing ideas"/></div></div>
    <div className="insight-main"><div className="insight-head"><span>How the story feels</span><span>Sample analysis</span></div><div className="assessment"><span className="assessment-icon"><AudioLines size={18}/></span><div><strong>Lots of talking, few visual changes</strong><small>A new visual could make this section easier to follow</small></div></div><div className="density-bar"><span style={{width: `${project.analysis.speechPercent}%`}}/><i/></div><div className="density-labels"><span>Talking {project.analysis.speechPercent}%</span><span>Visuals {project.analysis.visualPercent}%</span></div></div>
    <div className="insight-warning"><TriangleAlert size={18}/><div><strong>Viewers may lose interest at 02:14</strong><p>The picture stays the same for {project.analysis.staticSeconds} seconds while an important point is explained. A chart or clip could help.</p></div></div>
    <div className="copilot-metrics"><span><BrainCircuit size={14}/> Demo analysis</span><span><span className="mini-pulse"/> 3 places to improve</span></div>
    <button className="gradient-action" disabled={analyzing} onClick={onAnalyze}>{analyzing ? <LoaderCircle className="spin" size={17}/> : analyzed ? <Check size={17}/> : <WandSparkles size={17}/>}<span>{analyzing ? 'Finding visual ideas...' : analyzed ? 'Find ideas again' : 'Find edit ideas'}</span><ArrowUpRight size={15}/></button>
  </Card>;
}
