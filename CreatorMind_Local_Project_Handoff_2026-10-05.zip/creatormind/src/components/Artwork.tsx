import { BarChart3, Building2, Clapperboard, Landmark } from 'lucide-react';
import type { Asset } from '../types';
import { cx } from './ui';

export function Artwork({ palette, className = '', title }: { palette: string; className?: string; title?: string }) {
  const Icon = palette === 'purple' || palette === 'pink' ? BarChart3 : palette === 'amber' ? Landmark : palette === 'teal' ? Building2 : Clapperboard;
  return <div className={cx('artwork', `artwork-${palette}`, className)} aria-label={title}>
    <div className="artwork-grid" />
    <div className="artwork-horizon" />
    <div className="artwork-building one" /><div className="artwork-building two" /><div className="artwork-building three" />
    <div className="artwork-icon"><Icon size={24} strokeWidth={1.4} /></div>
  </div>;
}

export function AssetArtwork({ asset, className = '' }: { asset: Asset; className?: string }) {
  return <Artwork palette={asset.palette} title={asset.title} className={className} />;
}
