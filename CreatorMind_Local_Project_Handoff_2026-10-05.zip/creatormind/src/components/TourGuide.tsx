import { useEffect, useRef } from 'react';
import { ArrowLeft, ArrowRight, Check, X } from 'lucide-react';

export const tourSteps = [
  {
    target: 'video',
    title: 'Start with your video',
    description: 'Press play to try the sample with sound. Use Load video to preview your own file here. Your file stays in this browser.',
    action: 'Try playing the sample, then continue.',
  },
  {
    target: 'ideas',
    title: 'Find places for more visuals',
    description: 'This block points out sections that may need a visual change. Select Find edit ideas to reveal the full set of demo suggestions.',
    action: 'The analysis is simulated with local sample data.',
  },
  {
    target: 'timeline',
    title: 'See where each idea belongs',
    description: 'The long bars show the main video. Colored markers show suggested clips or graphics. Select a marker to see why it helps and which media fits.',
    action: 'Select a marker to review its details.',
  },
  {
    target: 'localize',
    title: 'Adapt the story for your audience',
    description: 'Choose Japan, Indonesia, or India, then open its regional workspace. Edit the script, apply it to your edit plan, and download the finished wording.',
    action: 'The local demo saves script text; creating a dubbed video is a later production step.',
  },
  {
    target: 'status',
    title: 'Check what is happening behind the scenes',
    description: 'This panel shows sample processing and media-match numbers. They are demo values for now; no cloud service is connected.',
    action: 'When ready, download your edit plan at the top of the page.',
  },
] as const;

export function TourHelpButton({ onClick, label }: { onClick: () => void; label: string }) {
  return <button className="tour-help-button" onClick={onClick} aria-label={`Explain ${label}`} title={`Explain ${label}`}>?</button>;
}

export function TourGuide({ step, onStep, onClose }: { step: number; onStep: (step: number) => void; onClose: () => void }) {
  const panel = useRef<HTMLElement>(null);
  const previousFocus = useRef<HTMLElement | null>(document.activeElement as HTMLElement | null);
  const item = tourSteps[step];

  useEffect(() => {
    const target = document.querySelector<HTMLElement>(`[data-tour="${item.target}"]`);
    target?.classList.add('tour-highlight');
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches || Boolean(document.querySelector('.reduce-motion'));
    target?.scrollIntoView({ block: 'center', behavior: reduced ? 'instant' : 'smooth' });
    panel.current?.focus();
    return () => target?.classList.remove('tour-highlight');
  }, [item.target]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose]);

  useEffect(() => () => previousFocus.current?.focus(), []);

  return <><button className="tour-scrim" onClick={onClose} aria-label="End tour"/><section ref={panel} className={`tour-panel ${step === 1 || step === 4 ? 'tour-panel-left' : ''}`} role="dialog" aria-labelledby="tour-title" tabIndex={-1}><div className="tour-panel-top"><span>QUICK TOUR · {step + 1} OF {tourSteps.length}</span><button onClick={onClose} aria-label="Close tour"><X size={17}/></button></div><div className="tour-progress" aria-hidden="true">{tourSteps.map((_, index) => <i key={index} className={index <= step ? 'tour-progress-active' : ''}/>)}</div><h2 id="tour-title">{item.title}</h2><p>{item.description}</p><div className="tour-tip"><Check size={14}/>{item.action}</div><div className="tour-actions"><button onClick={step ? () => onStep(step - 1) : onClose}>{step ? <><ArrowLeft size={14}/> Back</> : 'Skip tour'}</button><button onClick={step === tourSteps.length - 1 ? onClose : () => onStep(step + 1)}>{step === tourSteps.length - 1 ? 'Finish tour' : 'Next'}<ArrowRight size={14}/></button></div></section></>;
}
