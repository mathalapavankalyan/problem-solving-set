import type { HTMLAttributes, ReactNode } from 'react';

export function cx(...classes: (string | false | null | undefined)[]) { return classes.filter(Boolean).join(' '); }

export function Card({ children, className = '', ...props }: HTMLAttributes<HTMLElement>) {
  return <section className={cx('panel', className)} {...props}>{children}</section>;
}

export function Eyebrow({ children, icon, tone = 'muted' }: { children: ReactNode; icon?: ReactNode; tone?: 'muted' | 'purple' | 'cyan' | 'amber' | 'green' }) {
  return <div className={cx('eyebrow', `eyebrow-${tone}`)}>{icon}{children}</div>;
}

export function StatusDot({ tone = 'green' }: { tone?: 'green' | 'amber' | 'purple' }) {
  return <span className={cx('status-dot', `status-dot-${tone}`)} />;
}
