import { Bell, ChevronDown, Command, Search, Sparkles } from 'lucide-react';
import type { View } from '../types';
import { StatusDot } from './ui';

const labels: Record<View, string> = { dashboard: 'Home', vault: 'Media Library', localizer: 'Localize', health: 'System Status' };

export function Topbar({ view, onNavigate, onSearch, onNotifications }: { view: View; onNavigate: (view: View) => void; onSearch: () => void; onNotifications: () => void }) {
  return <header className="topbar"><div className="breadcrumb"><span className="topbar-brand">Creator<span>Mind</span></span><span className="crumb-divider"/><button onClick={() => onNavigate('dashboard')}>Your project <ChevronDown size={12}/></button><span className="crumb-slash">/</span><strong>{labels[view]}</strong></div><div className="topbar-actions"><span className="topbar-sync"><StatusDot/>Local demo</span><button className="topbar-icon" onClick={onSearch} aria-label="Search media"><Search size={17}/></button><button className="topbar-icon" onClick={onNotifications} aria-label="Notifications"><Bell size={17}/><i /></button><span className="topbar-avatar" title="Alex Kim">AK</span></div><div className="mobile-brand"><Sparkles size={17}/> CreatorMind <span><Command size={12}/> Studio</span></div></header>;
}
