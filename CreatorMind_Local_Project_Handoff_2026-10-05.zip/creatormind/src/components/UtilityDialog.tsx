import { Compass, X } from 'lucide-react';
import { Eyebrow } from './ui';

type Utility = 'help' | 'settings' | 'notifications';

export function UtilityDialog({ panel, onClose, onStartTour, reduceMotion, onReduceMotion }: { panel: Utility | null; onClose: () => void; onStartTour: () => void; reduceMotion: boolean; onReduceMotion: (value: boolean) => void }) {
  if (!panel) return null;
  return <div className="dialog-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}><section className="utility-dialog" role="dialog" aria-modal="true" aria-label={panel}><button className="close-button" onClick={onClose} aria-label="Close panel"><X size={18}/></button><Eyebrow tone="purple">CreatorMind Studio</Eyebrow><h2>{panel === 'help' ? 'Need a hand?' : panel === 'settings' ? 'Your preferences' : 'Updates'}</h2>
    {panel === 'help' && <><p className="utility-intro">A short tour explains each part of the workspace and what to do next.</p><button className="gradient-action utility-tour-action" onClick={() => { onClose(); onStartTour(); }}><Compass size={16}/> Show me around</button><div className="utility-list"><p><strong>Play or load a video</strong><span>The sample has sound. Your own file stays in this browser.</span></p><p><strong>Find edit ideas</strong><span>Review sample suggestions on the timeline and choose the ones you like.</span></p><p><strong>Download your plan</strong><span>Save your selected edits as a JSON file.</span></p></div></>}
    {panel === 'settings' && <label className="utility-setting"><span><strong>Reduce motion</strong><small>Turn off interface animations and movement.</small></span><input type="checkbox" checked={reduceMotion} onChange={event => onReduceMotion(event.target.checked)}/></label>}
    {panel === 'notifications' && <div className="utility-list"><p><strong>Sample media library is ready</strong><span>You can browse clips and graphics for your edit.</span></p><p><strong>A visual change may help at 02:14</strong><span>Open the timeline to see a suggested chart.</span></p></div>}
  </section></div>;
}
