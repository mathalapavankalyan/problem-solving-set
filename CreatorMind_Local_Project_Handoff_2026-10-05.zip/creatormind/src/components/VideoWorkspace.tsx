import { useEffect, useRef, useState } from 'react';
import { Expand, Film, Pause, Play, SkipBack, SkipForward, UploadCloud, Volume2, VolumeX } from 'lucide-react';
import { formatBytes, timecode } from '../lib/format';
import { Card, Eyebrow } from './ui';
import { TourHelpButton } from './TourGuide';

const SAMPLE_SRC = '/media/sintel-trailer-720p.mp4';
const SAMPLE_DURATION = 52;

export function VideoWorkspace({ file, source, onUpload, onToast, onHelp }: { file: File | null; source: string | null; onUpload: (file: File) => void; onToast: (message: string) => void; onHelp: () => void }) {
  const input = useRef<HTMLInputElement>(null);
  const video = useRef<HTMLVideoElement>(null);
  const stage = useRef<HTMLDivElement>(null);
  const [playing, setPlaying] = useState(false);
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(SAMPLE_DURATION);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [mediaError, setMediaError] = useState(false);

  useEffect(() => {
    setPlaying(false);
    setCurrent(0);
    setDuration(SAMPLE_DURATION);
    setMuted(false);
    setVolume(1);
    setMediaError(false);
  }, [source]);

  useEffect(() => {
    if (!video.current) return;
    video.current.muted = muted;
    video.current.volume = volume;
  }, [muted, volume, source]);

  const togglePlayback = () => {
    const media = video.current;
    if (!media || mediaError) return;
    if (media.paused) {
      media.muted = muted;
      media.volume = volume;
      void media.play().catch(() => onToast('Playback was blocked. Click play again or check this video format.'));
    } else media.pause();
  };

  const seek = (value: number) => {
    if (!video.current || mediaError) return;
    video.current.currentTime = value;
    setCurrent(value);
  };

  return <Card className="video-card" data-tour="video">
    <div className="card-heading"><div><Eyebrow icon={<UploadCloud size={13}/>} tone="cyan">Your video</Eyebrow><h2>{file?.name ?? 'Sintel Trailer · Sample Video.mp4'}</h2><p>{file ? 'Your local video · audio on' : 'Sample with sound · the edit ideas below use a separate demo project'}</p></div><div className="card-heading-actions"><span className="file-size">{file ? formatBytes(file.size) : '7.3 MB'}</span><TourHelpButton onClick={onHelp} label="the video player"/></div></div>
    <div className="video-stage" ref={stage}>
      <video key={source ?? SAMPLE_SRC} ref={video} src={source ?? SAMPLE_SRC} muted={muted} preload="metadata" playsInline onTimeUpdate={event => setCurrent(event.currentTarget.currentTime)} onLoadedMetadata={event => { setDuration(event.currentTarget.duration || SAMPLE_DURATION); event.currentTarget.muted = false; event.currentTarget.volume = 1; }} onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onEnded={() => setPlaying(false)} onError={() => { setMediaError(true); onToast('This video could not be played. Try an MP4 with H.264 and AAC.'); }} />
      {mediaError && <div className="video-error"><strong>Video unavailable</strong><span>Load a local MP4 with a supported audio track to continue.</span><button onClick={() => input.current?.click()}>Choose video</button></div>}
      <div className="video-topline"><span className="proxy-badge"><i/> {file ? 'LOCAL VIDEO · AUDIO ON' : 'SAMPLE VIDEO · AUDIO ON'}</span><button className="video-expand" onClick={() => { if (stage.current?.requestFullscreen) void stage.current.requestFullscreen(); }} aria-label="Fullscreen"><Expand size={15}/></button></div>
      {!playing && !mediaError && <button className="video-center-play" onClick={togglePlayback} aria-label="Play video"><Play size={23} fill="currentColor"/></button>}
      <div className="video-overlay-bottom"><span>{file ? 'Local media preview' : 'Playback demo by Blender Foundation · CC BY 3.0'}</span><span>{file ? 'LOCAL' : '720P · AAC'}</span></div>
    </div>
    <div className="video-controls"><div className="video-transport"><button disabled={mediaError} onClick={() => seek(Math.max(0, current - 5))} aria-label="Skip back five seconds"><SkipBack size={16}/></button><button className="transport-main" disabled={mediaError} onClick={togglePlayback} aria-label={playing ? 'Pause' : 'Play'}>{playing ? <Pause size={16} fill="currentColor"/> : <Play size={16} fill="currentColor"/>}</button><button disabled={mediaError} onClick={() => seek(Math.min(duration, current + 5))} aria-label="Skip forward five seconds"><SkipForward size={16}/></button></div><span className="video-time">{timecode(current)} <i>/</i> {timecode(duration)}</span><input className="video-range" aria-label="Video position" type="range" min="0" max={duration || 1} value={Math.min(current, duration)} disabled={mediaError} onChange={event => seek(Number(event.target.value))} style={{ ['--progress' as string]: `${duration ? current / duration * 100 : 0}%` }}/><div className="volume-controls"><button className="volume-button" disabled={mediaError} onClick={() => setMuted(value => !value)} aria-label={muted ? 'Unmute' : 'Mute'}>{muted || volume === 0 ? <VolumeX size={16}/> : <Volume2 size={16}/>}</button><input className="volume-range" aria-label="Volume" type="range" min="0" max="1" step="0.05" value={muted ? 0 : volume} disabled={mediaError} onChange={event => { const next = Number(event.target.value); setVolume(next); setMuted(next === 0); }}/></div><input ref={input} type="file" accept="video/*" className="sr-only" onChange={event => { const next = event.target.files?.[0]; if (next) onUpload(next); event.target.value = ''; }}/><button className="replace-button" onClick={() => input.current?.click()}><Film size={14}/> {file ? 'Replace' : 'Load video'}</button></div>
  </Card>;
}
