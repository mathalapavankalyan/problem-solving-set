import { ArrowRight, Globe2, PenLine } from 'lucide-react';
import { markets } from '../data';
import { Card, Eyebrow, cx } from './ui';
import { TourHelpButton } from './TourGuide';

export function LocalizerCard({ marketCode, onMarket, onOpen, onHelp }: { marketCode: string; onMarket: (code: string) => void; onOpen: () => void; onHelp: () => void }) {
  const market = markets.find(item => item.code === marketCode) ?? markets[0];
  return <Card className="localizer-card" data-tour="localize"><div className="card-heading"><div><Eyebrow icon={<Globe2 size={13}/>} tone="amber">Make it local</Eyebrow><h2>Adapt for your audience</h2><p>Choose a country to see examples your viewers know</p></div><div className="card-heading-actions"><span className="pill pill-outline">3 countries</span><TourHelpButton onClick={onHelp} label="regional versions"/></div></div><div className="country-grid">{markets.map(item => <button key={item.code} className={cx('country-button',marketCode===item.code && 'country-active')} onClick={() => onMarket(item.code)}><span>{item.flag}</span><strong>{item.name}</strong></button>)}</div><div className="local-context"><div><span>Local business hub</span><strong>{market.hub}</strong></div><div><span>Story tone</span><strong>{market.tone}</strong></div></div><div className="swap-list"><div className="swap-title"><span>Examples to replace</span><span>{market.swaps.length} ideas</span></div>{market.swaps.map(swap => <div key={swap.from} className="swap-row"><span>{swap.from}</span><ArrowRight size={12}/><strong>{swap.to}</strong></div>)}</div><button className="subtle-button" onClick={onOpen}><PenLine size={14}/> Edit {market.name} script <ArrowRight size={13}/></button></Card>;
}
