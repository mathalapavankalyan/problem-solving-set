import { useEffect, useState } from 'react';
import { Activity, CloudUpload, Cpu, Database, Radio, Server } from 'lucide-react';
import { telemetry } from '../data';
import { Card, Eyebrow, StatusDot } from './ui';
import { TourHelpButton } from './TourGuide';

export function TelemetryCard({ onHelp }: { onHelp: () => void }) {
  const [tick,setTick] = useState(0);
  useEffect(() => { const id = window.setInterval(() => setTick(value => value + 1), 2400); return () => window.clearInterval(id); }, []);
  const latency = (telemetry.latencySeconds + Math.sin(tick * 1.37) * .025).toFixed(2);
  const rate = (telemetry.uploadRateMbps + Math.sin(tick * .8) * .4).toFixed(1);
  return <Card className="telemetry-card" data-tour="status"><div className="card-heading"><div><Eyebrow icon={<Radio size={13}/>} tone="green">Behind the scenes</Eyebrow><h2>Demo system status</h2><p>Sample numbers showing how processing would work</p></div><div className="card-heading-actions"><span className="live-label"><StatusDot/> SIMULATED</span><TourHelpButton onClick={onHelp} label="system status"/></div></div><div className="telemetry-rows"><div className="telemetry-row"><span className="telemetry-icon purple"><Cpu size={18}/></span><div><strong>AI response time</strong><small>Sample Gemini result · {telemetry.modelRegion}</small></div><div className="telemetry-value"><strong>{latency}s</strong><small>Demo time</small></div></div><div className="telemetry-row"><span className="telemetry-icon cyan"><CloudUpload size={18}/></span><div><strong>Video transfer</strong><small>Sample speed · {rate} MB/s</small></div><div className="telemetry-value"><strong className="value-active"><StatusDot/> Ready</strong><small>Demo state</small></div></div><div className="telemetry-row"><span className="telemetry-icon blue"><Database size={18}/></span><div><strong>Matching media found</strong><small>Sample media library</small></div><div className="telemetry-value"><strong>{telemetry.semanticAssetCount}</strong><small>Clips</small></div></div></div><div className="telemetry-footer"><span><Server size={13}/> Sample region: {telemetry.region}</span><span><Activity size={13}/> Local demo</span></div></Card>;
}
