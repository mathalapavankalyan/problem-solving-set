import { useState } from 'react';
import { ArrowRight, Check, Clock3, Copy, Download, Globe2, Lightbulb, MapPin, Quote, RotateCcw, Sparkles } from 'lucide-react';
import { markets, project } from '../data';
import { Card, Eyebrow, cx } from './ui';

type Props = {
  marketCode: string;
  onMarket: (code: string) => void;
  onToast: (message: string) => void;
  draft: string;
  applied: string | null;
  onDraft: (value: string) => void;
  onApply: () => void;
  onReset: () => void;
  onDownload: () => void;
};

export function LocalizationPage({ marketCode, onMarket, onToast, draft, applied, onDraft, onApply, onReset, onDownload }: Props) {
  const [copied, setCopied] = useState(false);
  const market = markets.find(item => item.code === marketCode) ?? markets[0];
  const isApplied = applied !== null && applied === draft;
  const status = isApplied ? 'Applied to edit plan' : applied ? 'Changes need applying' : 'Not applied yet';

  const copyScript = async () => {
    try {
      await navigator.clipboard.writeText(draft);
      setCopied(true);
      onToast(`${market.name} script copied`);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      onToast('Clipboard access is unavailable in this browser.');
    }
  };

  return <div className="page-stack">
    <div className="page-intro"><div><Eyebrow icon={<Globe2 size={14}/>} tone="amber">Make it local</Eyebrow><h1>Regional versions<span className="heading-dot amber-dot">.</span></h1><p>Choose a country, adjust the words, and save a script for that audience.</p></div><span className="page-count"><Sparkles size={15}/> Local script workspace</span></div>
    <div className="localize-steps" aria-label="How to make a regional version"><span><b>1</b> Choose a country</span><ArrowRight size={14}/><span><b>2</b> Edit the script</span><ArrowRight size={14}/><span><b>3</b> Apply and download</span></div>
    <div className="localizer-page-grid">
      <Card className="market-picker"><div className="section-heading"><div><Eyebrow tone="amber">Your audience</Eyebrow><h2>Choose a country</h2></div><span>01 / 03</span></div><div className="market-list">{markets.map(item => <button key={item.code} onClick={() => onMarket(item.code)} className={cx('market-option', item.code === marketCode && 'market-option-active')}><span className="market-flag">{item.flag}</span><span><strong>{item.name}</strong><small>{item.hub}</small></span><ArrowRight size={16}/></button>)}</div><div className="market-fact"><MapPin size={15}/><div><span>Local setting</span><strong>{market.hub}</strong></div></div><div className="market-fact"><Quote size={15}/><div><span>How it should sound</span><strong>{market.tone}</strong></div></div><div className="market-fact"><Clock3 size={15}/><div><span>Best time to post (sample)</span><strong>{market.postingWindow}</strong></div></div></Card>
      <div className="localizer-detail">
        <Card className="script-card"><div className="section-heading"><div><Eyebrow icon={<Sparkles size={13}/>} tone="purple">Your new wording</Eyebrow><h2>{market.flag} {market.name} script</h2></div><span className={cx('script-status', isApplied && 'script-status-applied')}>{isApplied && <Check size={13}/>} {status}</span></div>
          <div className="script-comparison"><div><span>Original script</span><p>{project.script}</p></div><ArrowRight size={18}/><div><label htmlFor="regional-script">Your {market.name} script</label><textarea id="regional-script" value={draft} onChange={event => onDraft(event.target.value)} spellCheck aria-describedby="script-help"/><small>{draft.trim().split(/\s+/).filter(Boolean).length} words · Saved in this browser as you type</small></div></div>
          <div className="script-actions"><button className="copy-button" onClick={copyScript} disabled={!draft.trim()}>{copied ? <Check size={15}/> : <Copy size={15}/>} {copied ? 'Copied' : 'Copy'}</button><button className="copy-button" onClick={onReset}><RotateCcw size={15}/> Use suggested wording</button><button className="copy-button" onClick={onDownload} disabled={!isApplied}><Download size={15}/> Download script</button><button className="script-apply-button" onClick={onApply} disabled={!draft.trim() || isApplied}><Check size={15}/> Apply to {market.name} version</button></div>
          <p className="localize-note" id="script-help">Applying saves this country's script in your browser and adds it to the downloaded edit plan. To make a video in this language, record or generate its narration and replace the original audio in a video editor. This local demo does not change the video's audio or render a new video.</p>
        </Card>
        <Card className="swap-card"><div className="section-heading"><div><Eyebrow tone="cyan">Local examples</Eyebrow><h2>What changes for this audience</h2></div><span>{market.swaps.length} changes</span></div><div className="swap-table">{market.swaps.map(swap => <div key={swap.from}><span>{swap.from}</span><ArrowRight size={15}/><strong>{swap.to}</strong></div>)}</div></Card>
        <Card className="strategy-card"><div className="strategy-icon"><Lightbulb size={19}/></div><div><Eyebrow tone="amber">Posting tip</Eyebrow><h2>{market.audience}</h2><p>{market.tip}</p><div>{market.hashtags.map(tag => <span key={tag}>{tag}</span>)}</div></div></Card>
      </div>
    </div>
  </div>;
}
