import { Activity, CircleHelp, Clapperboard, Languages, LayoutDashboard, Layers3, Menu, Settings2, X } from 'lucide-react';
import type { View } from '../types';
import { cx } from './ui';

const items: { view: View; label: string; icon: typeof LayoutDashboard }[] = [
  { view: 'dashboard', label: 'Home', icon: LayoutDashboard },
  { view: 'vault', label: 'Media Library', icon: Clapperboard },
  { view: 'localizer', label: 'Localize', icon: Languages },
  { view: 'health', label: 'System Status', icon: Activity },
];

export function Sidebar({ view, onView, mobileOpen, onMobileOpen, onUtility }: { view: View; onView: (view: View) => void; mobileOpen: boolean; onMobileOpen: (open: boolean) => void; onUtility: (panel: 'help' | 'settings') => void }) {
  return <>
    <button className="mobile-menu-button" onClick={() => onMobileOpen(true)} aria-label="Open navigation"><Menu size={19} /></button>
    {mobileOpen && <button className="sidebar-scrim" onClick={() => onMobileOpen(false)} aria-label="Close navigation" />}
    <aside className={cx('sidebar', mobileOpen && 'sidebar-open')}>
      <div className="sidebar-logo" aria-label="CreatorMind"><Layers3 size={22} strokeWidth={2.2} /></div>
      <div className="sidebar-rule" />
      <nav className="sidebar-nav" aria-label="Main navigation">
        {items.map(({ view: itemView, label, icon: Icon }) => <button key={itemView} className={cx('sidebar-link', view === itemView && 'sidebar-link-active')} onClick={() => { onView(itemView); onMobileOpen(false); }} aria-current={view === itemView ? 'page' : undefined} title={label}><Icon size={19} strokeWidth={1.8}/><span className="sidebar-link-label">{label}</span></button>)}
      </nav>
      <div className="sidebar-bottom"><button className="sidebar-link" title="Help" aria-label="Help" onClick={() => onUtility('help')}><CircleHelp size={18}/><span className="sidebar-link-label">Help</span></button><button className="sidebar-link" title="Settings" aria-label="Settings" onClick={() => onUtility('settings')}><Settings2 size={18}/><span className="sidebar-link-label">Settings</span></button></div>
      <button className="sidebar-close" onClick={() => onMobileOpen(false)} aria-label="Close navigation"><X size={18}/></button>
    </aside>
  </>;
}
