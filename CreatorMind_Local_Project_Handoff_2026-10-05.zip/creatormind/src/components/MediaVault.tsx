import { useMemo, useState } from 'react';
import { ArrowUpRight, Clapperboard, Database, FileVideo2, Filter, Search } from 'lucide-react';
import { assets, project } from '../data';
import type { Asset } from '../types';
import { AssetArtwork } from './Artwork';
import { Card, Eyebrow, cx } from './ui';

const filters = ['All assets', 'Video', 'Graphic', 'Motion'];
export function MediaVault({ query, onQuery, onAsset }: { query: string; onQuery: (query: string) => void; onAsset: (asset: Asset) => void }) {
  const [filter,setFilter] = useState('All assets');
  const visible = useMemo(() => assets.filter(asset => (filter === 'All assets' || asset.type === filter) && `${asset.title} ${asset.file} ${asset.tags.join(' ')} ${asset.region}`.toLowerCase().includes(query.toLowerCase())),[filter,query]);
  return <div className="page-stack"><div className="page-intro"><div><Eyebrow icon={<Clapperboard size={14}/>} tone="cyan">Clips and graphics</Eyebrow><h1>Media library<span className="heading-dot">.</span></h1><p>Find a clip or graphic that helps tell your story.</p></div><span className="page-count"><Database size={15}/> {assets.length} sample items · {project.name}</span></div><Card className="vault-toolbar"><div className="vault-search"><Search size={17}/><input value={query} onChange={event => onQuery(event.target.value)} placeholder="Search clips, topics, or countries..." aria-label="Search assets"/></div><div className="vault-filters"><Filter size={15}/>{filters.map(item => <button key={item} onClick={() => setFilter(item)} className={cx(filter===item&&'filter-active')}>{item}</button>)}</div></Card><div className="vault-grid">{visible.map(asset => <button className="vault-tile" key={asset.id} onClick={() => onAsset(asset)}><AssetArtwork asset={asset} className="vault-tile-art"/><span className="vault-tile-top"><span>{asset.type}</span><ArrowUpRight size={15}/></span><span className="vault-tile-body"><strong>{asset.title}</strong><small><FileVideo2 size={12}/>{asset.file}</small><span>{asset.tags.slice(0,3).map(tag => <em key={tag}>{tag}</em>)}</span></span><span className="vault-tile-footer"><span>{asset.region} · {asset.duration}</span><strong>{asset.match}% match</strong></span></button>)}</div>{!visible.length&&<div className="empty-state"><Search size={27}/><strong>No clips found</strong><span>Try another search or choose a different filter.</span></div>}</div>;
}
