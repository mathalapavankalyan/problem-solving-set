# CreatorMind UI generation prompt — local application, version 2

Act as a principal product designer and lead frontend engineer. Build the **CreatorMind Multi-Modal B-Roll Orchestrator** as a complete, runnable local web application for high-growth digital media creators who need to turn a spoken A-roll video into a reviewable edit decision list (EDL). The primary task is: **load a video → inspect pacing risks → review visual recommendations and asset matches → localize the story → export the EDL**. Optimize the interface for a creator working for several hours in a production suite, not for a one-screen hackathon screenshot.

## Product and implementation context

- Build with React, TypeScript, Vite, Tailwind CSS, and Lucide React. Use multiple files with clear boundaries for app state, fixtures, reusable components, views, and styles. Do not deliver a single HTML file or a single oversized component.
- This is the **local version**. Read project, suggestions, asset matches, localization, and telemetry from local JSON files. Persist only small user choices, such as region and queued EDL edits, in local storage. No database, authentication, Firebase, GCS, Vertex AI, or BigQuery connection is required yet.
- Mock data should feel operationally credible but must be labeled **simulated**. Never present a simulated status as a verified cloud connection. Keep timestamps, asset counts, file sizes, confidence values, and EDL entries internally consistent.
- Include one locally bundled, legally reusable, good-quality sample video with an audible track. Document its source, license, resolution, duration, and audio codec. The default player must load that actual video and play its real audio. If the sample is unavailable, show an explicit media-empty state and a clear **Load video** action; never animate a fake play clock or display an enabled volume control for a silent image.
- Support selecting a local video file without uploading it anywhere. Its player must use native browser media playback underneath the custom controls, start unmuted, and support play/pause, seek, mute, volume, duration display, and useful unsupported-codec feedback.

## Audience and experience goals

The primary user is a solo or small-team editor producing a finance or technology video for Japan, Indonesia, and India. They need to understand **what to edit, why, where, and with which asset** without learning cloud infrastructure. Make the workflow obvious on first use. Keep the timeline and media as the visual focus; place model and pipeline status in supporting positions. Use clear creator language such as “Visual gap at 02:14” and “Add matched graphic,” with technical details available on inspection.

## Visual direction and design system

- **Mood:** precise, cinematic, editorial, calm under dense information. Use the visual language of a professional editing suite with restrained Swiss grid discipline. Avoid a generic SaaS card wall, decorative charts with no meaning, excessive glow, and tiny low-contrast text.
- **Colors:** background `#0D0E12`, raised surfaces around `#161920`, subtle 1px borders. Reserve neon purple `#8B5CF6` for AI actions and selected recommendations, cyan `#06B6D4` for search and media intelligence, amber `#F59E0B` for retention risks, and emerald `#10B981` for confirmed local status. Use layered dark surfaces and verified readable text contrast.
- **Typography:** use a clean geometric display face with a highly legible body face. Define a scale: page title 30–34px desktop / 24–28px mobile, section title 16–20px, body 13–15px, metadata at least 11–12px. Use uppercase micro-labels sparingly. Show timecodes and numerical metrics in a tabular or monospace style.
- **Spacing:** 8px spacing system, 16px card radius, 20–24px card padding, 16–20px grid gaps, maximum content width around 1500px. Establish clear alignment between card headings, tools, and metrics.
- Use real video frames or a purposeful poster for the media player. Asset thumbnails should communicate skyline, finance, chart, or trading-floor content. Avoid repeating the same abstract gradient for every asset.
- Provide reusable button, badge, input, card, empty-state, toast, and dialog patterns with default, hover, focus, active, disabled, loading, and error treatments.

## Information architecture and screens

**Navigation:** a slim left desktop rail with CreatorMind branding and Dashboard, Media Vault, JAPAC Localizer, and Infrastructure Health. Highlight the current destination with both color and a shape or indicator. On mobile, use a labeled menu or bottom navigation; do not leave icon-only destinations unexplained. Top bar contains project context, search, notifications, and a local/simulated status indicator.

**Dashboard (primary workspace):** use a 12-column desktop grid. Give the video player about 7 columns and Copilot about 5 columns in the first row. Put a full-width multi-track timeline below, then regional context and telemetry cards. Include a clear primary action and a visible EDL queue count. The desktop first viewport should communicate the current project, media, most important retention risk, and next action.

1. **Raw media workspace:** default to an actual audible sample clip. Show its real title, duration, size, resolution, and whether it is bundled or selected locally. Provide play/pause, seek, volume, mute, fullscreen, replace, and an understandable playback error. Preserve aspect ratio and avoid overlaying controls on subtitles or important content.
2. **AI Copilot Insights:** show “High Density Speech Track,” a concise visual-to-speech balance, confidence, and a prominent amber risk at `02:14` caused by missing cuts. Provide **Inject Structural EDL Suggestions**. On click, show a short, staged local processing state and then reveal recommendations; do not imply a real model call.
3. **Multi-modal timeline:** display time ruler, A-roll chapters, AI B-roll/graphic recommendations, audio waveform or speech density, and an amber risk marker. Place recommendations by timestamp. Clicking one updates its selected style and an always-visible detail summary, then opens a detail drawer or dialog with diagnosis, action, duration, top matched asset, match score, tags, alternative assets, and **Queue in EDL**. Selection must remain understandable without relying only on color. Make the timeline horizontally scrollable and usable on narrow screens.
4. **JAPAC cultural context:** switch Japan, Indonesia, and India with labeled flag selectors. Show regional hub, tone, concept swaps, a localized script excerpt, and an engagement tip. Switching must update all displayed market content immediately.
5. **Telemetry:** show simulated Vertex inference latency near `0.38s`, GCS stream status, and `142` semantic matches. Use restrained ticking values, source labels, and a prominent **Simulated local data** disclosure. Do not use a green “connected” claim when no service is connected.

**Media Vault:** searchable/filterable asset library with meaningful thumbnails, type, duration, region, tags, and match score. Clicking an asset opens details and a path back to its timeline recommendation. Include a true no-results state.

**JAPAC Localizer:** a focused market picker, original-versus-localized script comparison, reference-swap table, tone guidance, posting window, and copy action. Reflect the selected market across dashboard and page.

**Infrastructure Health:** service map and telemetry cards clearly marked as local simulation, plus recent event examples. Make this informative for judges without overwhelming the creator's primary editing workflow.

## Interaction journey and states

Implement the full first-run journey: open a sample project; play the audible sample; run local analysis; select the `00:45` Singapore skyline recommendation; inspect `fintech`, `office`, and `skyscrapers` asset tags; queue an asset; inspect the `02:14` chart overlay warning; switch to Indonesia or India; export the current EDL as valid JSON. Every visible control must work or be clearly disabled with a reason. Define loading, success, empty, unsupported-media, and no-search-results states. Keep dialogs keyboard dismissible and return focus to the trigger. Use accessible status announcements for completed actions.

## Responsive and accessibility requirements

- Desktop at 1280px and above: dense but readable production grid with persistent left rail. Tablet from 768–1279px: two-column cards and scrollable timeline. Mobile under 768px: single-column flow, labeled navigation, player controls reachable by thumb, and no hidden upload or volume action. At 390px wide, cards must not overflow the viewport; the timeline may scroll inside its own container.
- Minimum 44×44px touch targets where practical, visible 2px focus indicators, keyboard-operable controls, `aria-label` on icon buttons, semantic headings, and accessible dialog behavior. Meet WCAG AA text contrast, including muted metadata. Respect `prefers-reduced-motion` and provide a reduced-motion setting if adding ambient animation.
- Verify the primary workflow with a real audio-enabled sample in both desktop and mobile layouts. Check that captions, focus, controls, dialog content, and exported data remain usable.

## Deliverables

Provide the full source tree, local JSON fixtures, bundled sample media and license note, a concise README with setup commands, and a successful production build. Explain what is simulated and what is functional. Do not claim visual or audio verification unless it was actually performed.
